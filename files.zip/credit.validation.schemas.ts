import { z } from 'zod';

const objectIdRegex = /^[a-fA-F0-9]{24}$/;

// ─── Credit Packages ──────────────────────────────────────────────────────────

export const createCreditPackageSchema = z.object({
    name: z.string().min(1, 'Package name is required').max(60),
    description: z.string().max(200).optional(),
    credits: z
        .number({ required_error: 'Credits amount is required' })
        .int('Credits must be a whole number')
        .min(1, 'Package must contain at least 1 credit'),
    price: z
        .number({ required_error: 'Price is required' })
        .min(0, 'Price cannot be negative'),
    currency: z.string().max(10).optional().default('NGN'),
    isPopular: z.boolean().optional().default(false),
    sortOrder: z.number().int().min(0).optional().default(0),
});

export const updateCreditPackageSchema = z.object({
    name: z.string().min(1).max(60).optional(),
    description: z.string().max(200).optional(),
    credits: z.number().int().min(1).optional(),
    price: z.number().min(0).optional(),
    currency: z.string().max(10).optional(),
    isPopular: z.boolean().optional(),
    isActive: z.boolean().optional(),
    sortOrder: z.number().int().min(0).optional(),
});

// ─── Credit Config ────────────────────────────────────────────────────────────

export const upsertCreditConfigSchema = z.object({
    cashbackRatio: z
        .number({ required_error: 'Cashback ratio is required' })
        .min(0, 'Cashback ratio cannot be less than 0')
        .max(1, 'Cashback ratio cannot exceed 1'),
    registrationRewardAmount: z
        .number({ required_error: 'Registration reward amount is required' })
        .int('Must be a whole number')
        .min(0, 'Cannot be negative'),
    referralRewardAmount: z
        .number({ required_error: 'Referral reward amount is required' })
        .int('Must be a whole number')
        .min(0, 'Cannot be negative'),
    vipRequestCost: z
        .number({ required_error: 'VIP request cost is required' })
        .int('Must be a whole number')
        .min(1, 'VIP request cost must be at least 1 credit'),
});

// ─── Wallet / Purchase ────────────────────────────────────────────────────────

export const initiatePurchaseSchema = z.object({
    packageId: z
        .string({ required_error: 'Package ID is required' })
        .regex(objectIdRegex, 'Invalid package ID format'),
});

// ─── VIP Protection Toggle ────────────────────────────────────────────────────

export const vipProtectionSchema = z.object({
    enabled: z.boolean({ required_error: 'enabled must be true or false' }),
});
