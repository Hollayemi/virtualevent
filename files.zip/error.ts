import { Request, Response, NextFunction } from 'express';

export class AppError extends Error {
    statusCode: number;
    status: string;
    isOperational: boolean;

    constructor(message: string, statusCode: number, status: string = 'error') {
        super(message);
        this.statusCode = statusCode;
        this.status = status ? status : `${statusCode}`.startsWith('4') ? 'fail' : 'error';
        this.isOperational = true;
        Error.captureStackTrace(this, this.constructor);
    }
}

export interface AppResponse {
    data: (data: any, message?: string, status?: number) => void;
    success: (message?: string, status?: number) => void;
    error: (error: any, message?: string, code?: number) => void;
    errorMessage: (message: string, status?: number) => void;
    status: (code: number) => AppResponse;
    json: (body: any) => void;
    cookie: (name: string, value: string, options?: any) => AppResponse;
}

const responseHelpers = {
    data: function (this: Response, data: any, message = 'Success', status = 200): void {
        this.status(status).json({
            success: true,
            type: 'success',
            message,
            data,
            timestamp: new Date().toISOString(),
        });
    },

    success: function (this: Response, message = 'Operation successful', status = 200): void {
        this.status(status).json({
            success: true,
            type: 'success',
            message,
            timestamp: new Date().toISOString(),
        });
    },

    error: function (this: Response, error: any, message = 'An error occurred', code = 500): void {
        const isDev = process.env.NODE_ENV === 'development';
        this.status(code).json({
            success: false,
            type: 'error',
            message,
            ...(isDev && { error: error?.message, stack: error?.stack }),
            timestamp: new Date().toISOString(),
        });
    },

    errorMessage: function (this: Response, message = 'Bad request', status = 400): void {
        this.status(status).json({
            success: false,
            type: 'error',
            message,
            timestamp: new Date().toISOString(),
        });
    },
};

export const extendResponse = (req: Request, res: Response, next: NextFunction): void => {
    const appRes = res as unknown as AppResponse;
    appRes.data = responseHelpers.data.bind(res);
    appRes.success = responseHelpers.success.bind(res);
    appRes.error = responseHelpers.error.bind(res);
    appRes.errorMessage = responseHelpers.errorMessage.bind(res);
    next();
};

export const errorHandler = (err: any, req: Request, res: Response, next: NextFunction): void => {
    const appRes = res as unknown as AppResponse;
    err.statusCode = err.statusCode || 500;

    if (process.env.NODE_ENV === 'development') {
        appRes.error(err, err.message, err.statusCode);
        return;
    }

    let error = { ...err, message: err.message };

    if (err.name === 'CastError') {
        error = new AppError('Resource not found', 404);
    }

    if (err.code === 11000) {
        const field = Object.keys(err.keyValue || {})[0] || 'Field';
        error = new AppError(
            `${field.charAt(0).toUpperCase() + field.slice(1)} already exists`,
            409,
        );
    }

    if (err.name === 'ValidationError') {
        const messages = Object.values(err.errors).map((e: any) => e.message);
        error = new AppError(messages.join('. '), 400);
    }

    if (err.name === 'JsonWebTokenError') {
        error = new AppError('Invalid token. Please log in again', 401);
    }

    if (err.name === 'TokenExpiredError') {
        error = new AppError('Token expired. Please log in again', 401);
    }

    appRes.errorMessage(error.message || 'Something went wrong', error.statusCode || 500);
};

export const handle404 = (req: Request, res: Response): void => {
    (res as unknown as AppResponse).errorMessage(`Route ${req.originalUrl} not found`, 404);
};

export const asyncHandler = (fn: Function) => {
    return (req: Request, res: Response, next: NextFunction) => {
        Promise.resolve(fn(req, res, next)).catch(next);
    };
};

export const jsonParseErrorHandler = (
    err: any,
    req: Request,
    res: Response,
    next: NextFunction,
): void => {
    if (err instanceof SyntaxError && 'body' in err) {
        (res as unknown as AppResponse).errorMessage('Invalid JSON payload', 400);
        return;
    }
    next(err);
};
