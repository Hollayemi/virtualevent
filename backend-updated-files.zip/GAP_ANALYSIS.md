# Gap Analysis: Frontend API Slices vs. Backend (Hollayemi/virtualevent)

This maps every endpoint in the 6 uploaded RTK Query slices to the backend at
`github.com/Hollayemi/virtualevent`, records what was missing or mismatched,
and summarizes what was implemented. Diffs are in the attached `backend-updates.zip`
(apply on top of your `master`).

## TL;DR

| Slice | Backend before | Status after |
|---|---|---|
| `connection.slice.ts` | Endpoints existed but were **event-nested** (`/events/:id/connections`) with a single combined accept/decline action, missing `cancelled` status, missing `stats`/`pending-count`/`received`/`sent` | ✅ New flat routes added under `/connections`, matching the slice exactly. Old nested routes kept for backward compatibility. |
| `discover.slice.ts` | Did not exist at all (closest thing was `GET /events/:eventId/attendees`) | ✅ New `discover` module: model-free, built on existing Attendee/Registration/Connection data |
| `profile.slice.ts` | Did not exist (closest: `GET/PATCH /users/me`, different shape) | ✅ New `profile` module |
| `settings.slice.ts` | Did not exist. No notification-preferences model, no dual-role support despite the "switch on the other role later" comment already in the code | ✅ New `settings` module; `User` model extended with `notifications`, `roles`, `activeRole` |
| `wallet.slice.ts` | A *different* wallet API already existed (`/wallet/me`, `/wallet/me/transactions`, `/wallet/purchase/initiate` + callback) — this is what `userApi.ts` talks to | ✅ New flat surface added alongside the legacy one: `/wallet/balance`, `/wallet/transactions`, `/wallet/packages`, `/wallet/purchase`, `/wallet/pending-cashback` |
| `userApi.ts` | Matches the **existing legacy** wallet/registrations/credit-packages routes reasonably well already | No changes needed — this appears to be the old slice being superseded by `wallet.slice.ts` + `connection.slice.ts`. Recommend deleting once the frontend migrates. |

---

## 1. Structural mismatches that needed a design decision

### 1.1 Tier is not a stored field — it's derived
Frontend types (`ConnectionUser.tier`, `DiscoverAttendee.tier`, `Profile.tier`) all
assume a fixed `'Regular' | 'Premium' | 'VIP'` union. The backend has **no such
field** anywhere. Tiers are defined *per event* (`Event.tiers[]`), each with a
free-form `label`, a `price`, and an `isVIP` flag on exactly one (the highest-priced)
tier.

**Decision:** added `src/helpers/tier.ts` → `bucketTier()`, which derives the bucket
from a per-event tier snapshot:
- `isVIP === true` → `'VIP'`
- `price > 0` (and not the VIP tier) → `'Premium'`
- `price === 0` → `'Regular'`

This is a heuristic, not a real design decision on your part — if tier is meant to be
a durable per-user attribute (e.g., a "Premium member" badge independent of any one
event), you'll want a stored field instead. Flagged inline in the code.

### 1.2 `initials` / `color` are not stored anywhere
Added `src/helpers/avatar.ts` (`getInitials`, `getColorForId`) — deterministic,
computed on the fly so the same user always renders the same initials/color.

### 1.3 `role` / `company` / `industry` live on `Attendee`, not `User`
The **existing** connection service was already trying to populate `company role`
directly off `User` (`.populate('userId', 'name email avatarUrl company role industry ...')`)
— those fields don't exist on the `User` schema, so it was silently returning
`undefined`. Fixed by populating the `attendeeProfile` sub-document everywhere
these fields are needed (connection, discover, profile modules).

### 1.4 `Event` had no `slug`
`types.ts` → `Event.slug` and everything that `Pick`s from it (`Connection.event`,
`ProfileWithEvents`) require it. Added a `slug` field to `Event.model.ts` with a
`pre('save')` hook that auto-generates a unique, URL-safe slug from `name` (with a
numeric-suffix fallback on collision). **This does not change any existing routing**
— events are still addressed by `:eventId` everywhere; `slug` is additive.

### 1.5 `ConnectionIntent` enum mismatch
Backend `INTENTION_TAGS` had `'Collaboration'` instead of frontend's `'Fundraising'`
and `'Just exploring'`. Realigned to match the frontend exactly (`utils/constants.ts`).
**If any existing `Connection` documents use `'Collaboration'`, migrate them before
deploying** — the enum no longer accepts that value.

### 1.6 No `cancelled` connection status
Frontend needs to withdraw a sent request (`cancelConnectionRequest`). Added
`'cancelled'` to `CONNECTION_STATUSES` and a `cancel()` instance method on the
`Connection` model. Cancelling a request that had spent credits now refunds them.

### 1.7 `Connection.creditCost` / `wasVipGated` were dead fields
The existing `sendConnectionRequest` debited the wallet correctly but **never wrote
`creditCost`/`wasVipGated` onto the created `Connection` document** — both stayed at
their schema defaults (`0`/`false`) forever. This silently broke anything downstream
that needed to know whether/how much was spent (which is exactly what the new
accept-cashback and cancel-refund logic needs). Fixed as part of this change.

### 1.8 Cashback was never actually paid
`respondToConnection`'s accept path called `connection.accept()` and nothing else —
no cashback credit despite `CreditConfig.cashbackRatio` and `getCashbackAmount()`
existing and clearly intended for this. The new `acceptConnectionFlat` computes and
credits cashback (`source: 'connection_accept'`) when the original request was
VIP-gated.

### 1.9 Settings' dual-role model didn't exist
`accountType` is a single `'attendee' | 'organiser'` value baked in at registration.
`settings.slice.ts` (and a code comment already in `settings.routes` intent —
`enableOrganizerRole`: *"the 'switch on the other role later' promise from
onboarding"*) wants a user to hold **both** roles and toggle an `activeRole`.

**Decision:** added `roles: { attendee, organizer }` and `activeRole` to `User`,
independent of the existing `accountType` field (left untouched — it's load-bearing
for the current `requireAccountType` auth middleware and I didn't want to risk
breaking existing auth checks). `POST /settings/roles/organizer` now creates an
`Organiser` profile on demand and flips `roles.organizer` on.

**Known naming collision to be aware of:** the JWT payload's `accountType` claim
(`'user' | 'organiser'`, checked by `requireAccountType`) is a *different concept*
from the new `User.roles.attendee/organizer` toggle. They currently aren't kept in
sync. If you want switching `activeRole` to actually change what routes a token can
hit, that requires re-issuing the JWT on role switch — not done here, flagged for
your call.

### 1.10 `WalletTransaction.source` / `kind` / `eventId` didn't exist
Backend `CreditTransaction.type` is `'purchase' | 'spend' | 'earn' | 'cashback' |
'refund'`. Frontend wants both a coarser `kind: 'credit' | 'debit' | 'pending'`
**and** a more granular `source` (`'connection_request'`, `'meeting_booking'`, etc.),
plus `eventId`/`eventName` for per-event filtering. Added `source`, `eventId`,
`eventName` as new (optional) fields on `CreditTransaction`; `kind` is derived from
`type` at read time (not stored). All new credit/debit call sites now pass a
`source` + `eventId`.

### 1.11 Avatar upload had no backend at all
No multer, no storage. Added `middleware/upload.ts` (multer, local disk under
`/uploads/avatars`, 5MB limit, images only) and `express.static('uploads')` in
`server.ts`. **This is a placeholder** — swap the `diskStorage` for S3/Cloudinary/etc.
before shipping to a multi-instance deployment (local disk won't survive a restart
or scale past one dyno/pod).

---

## 2. New modules created

### `discover` (`services|controllers|routes/discover.*`)
- `GET /discover/attendees` — filtered, paginated, scoped to `eventId`
- `GET /discover/suggested` — ranked by a **transparent heuristic**, not a trained
  model: shared interests (up to 60 pts) + same industry (30 pts), capped at 100.
  `matchReason` is a plain-English sentence built from the same signal. If you want
  real ML-driven suggestions, this is the seam to replace.
- `GET /discover/attendees/:userId` — single attendee detail
- `POST /discover/attendees/:userId/connect` — thin wrapper that delegates to the
  same `connection.service.sendFlatConnectionRequest` used by `/connections/request`
  (no duplicated business logic)
- `GET /discover/filters` — distinct industries/roles/interests actually present
  among an event's confirmed attendees; `tiers` is always `['Regular','Premium','VIP']`

⚠️ Performance note: role/industry/interest filtering happens **after** populating
because those fields live on a populated sub-document two hops away from
`Registration` (`Registration.userId → User.attendeeProfile → Attendee`). Fine for
event sizes in the hundreds; if events get into the thousands of attendees, replace
with an aggregation pipeline (`$lookup` chain) instead of in-memory `.filter()`.

### `profile` (`services|controllers|routes/profile.*`)
- `GET /profile`, `GET /profile/:userId`, `PATCH /profile` (transparently splits
  writes across `User` and `Attendee`), `POST /profile/avatar`, `GET
  /profile/business-card`, `GET /profile/events`
- `qrCodeData`/`shareUrl` on the business card are both just a profile URL string —
  no QR image is actually rendered server-side. If you want a real QR code image,
  add a `qrcode` package call in `profile.service.getBusinessCard`.

### `settings` (`services|controllers|routes/settings.*`)
- `GET /settings`, `PATCH /settings/account` (requires current password to change
  email/password), `PATCH /settings/notifications`, `POST /settings/roles/organizer`,
  `PATCH /settings/roles/active`, `DELETE /settings/account` (soft delete: sets
  `deletionScheduledFor` 30 days out — **no actual purge job exists**, you'll need a
  scheduled task to hard-delete accounts past that date, and to reject
  login/writes for accounts with `deletionScheduledFor` set in the meantime, neither
  of which is wired up yet).

---

## 3. Files changed

**Modified:**
- `src/config/env.ts` — added `SERVER_URL`
- `src/controllers/connection.controller.ts` — added flat handlers
- `src/controllers/wallet.controller.ts` — added flat handlers
- `src/helpers/validation.schemas.ts` — new Joi schemas
- `src/models/Connection.model.ts` — `cancel()` method
- `src/models/CreditTransaction.model.ts` — `source`, `eventId`, `eventName`
- `src/models/Event.model.ts` — `slug` field + generation
- `src/models/User.model.ts` — `roles`, `activeRole`, `notifications`, `preferredLanguage`, `timezone`, `deletionScheduledFor`
- `src/routes/connection.routes.ts` — rewritten (flat + legacy `respond` kept)
- `src/routes/wallet.routes.ts` — added flat routes
- `src/server.ts` — mounted new routers + static `/uploads`
- `src/services/connection.service.ts` — fixed `creditCost`/`wasVipGated` bug, added flat functions, cashback-on-accept, refund-on-cancel
- `src/services/user.service.ts` — initialize `roles`/`activeRole` at registration
- `src/services/wallet.service.ts` — `source`/`eventId`/`eventName` plumbing, new flat functions
- `src/utils/constants.ts` — `INTENTION_TAGS`, `CONNECTION_STATUSES`, `TIER_BUCKETS`

**New:**
- `src/helpers/tier.ts`, `src/helpers/avatar.ts`
- `src/middleware/upload.ts`
- `src/services/discover.service.ts`, `src/controllers/discover.controller.ts`, `src/routes/discover.routes.ts`
- `src/services/profile.service.ts`, `src/controllers/profile.controller.ts`, `src/routes/profile.routes.ts`
- `src/services/settings.service.ts`, `src/controllers/settings.controller.ts`, `src/routes/settings.routes.ts`

`npx tsc --noEmit` passes clean on the whole project after these changes.

---

## 4. What's deliberately NOT done (needs your call)

1. **No DB migration script.** Existing `Connection` docs with `intentionTag:
   'Collaboration'` or missing `creditCost`/`wasVipGated` won't retroactively be
   fixed. Existing `User` docs will lazily get the new `roles`/`notifications`
   defaults from the schema, but won't have `roles.organizer` synced with an
   existing `organiserProfile` if one already exists — run a one-off script if you
   have existing organiser accounts.
2. **No cloud storage for avatars** — local disk only (see §1.11).
3. **No account-deletion purge job / login block** for accounts past their grace
   period (see §"settings" above).
4. **`activeRole` doesn't affect JWT-based route authorization** (see §1.9).
5. **`userApi.ts` left untouched** — it already matches the legacy wallet API. Confirm
   with whoever owns the frontend whether it's still in use before deleting it.
